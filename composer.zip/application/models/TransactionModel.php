<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
class TransactionModel extends CI_Model 
{ 
    private $table = 'transactions'; 
    public $id; 
    public $id_user; 
    public $id_hairstyle; 
    public $id_barber; 
    public $id_service;
    public $book_date;
    public $order_date;
    public $rule = [ 
        [ 
            'field' => 'id_user', 
            'label' => 'id_user', 
            'rules' => 'required' 
        ], 
        [ 
            'field' => 'id_hairstyle', 
            'label' => 'id_hairstyle', 
            'rules' => 'required' 
        ],
        [ 
            'field' => 'id_barber', 
            'label' => 'id_barber', 
            'rules' => 'required' 
        ],
        [ 
            'field' => 'id_service', 
            'label' => 'id_service', 
            'rules' => 'required' 
        ],
    ]; 
    public function Rules() { return $this->rule; } 
    
    // public function getAll() { return 
    //     $this->db->get('data_mahasiswa')->result(); 
    // } 
    
    public function store($request) { 
        $this->id_user = $request->id_user; 
        $this->id_hairstyle = $request->id_hairstyle; 
        $this->id_barber = $request->id_barber;
        $this->id_service = $request->id_service;
        $this->book_date = $request->book_date;
        $this->order_date = $request->order_date;

        if($this->db->insert($this->table, $this)){ 
            return ['msg'=>'Success','error'=>false];
        } 
        return ['msg'=>'Failed','error'=>true]; 
    } 
    public function update($request,$id) { 
        $updateData = [
            'id_user' => $request->id_user,
            'id_hairstyle' => $request->id_hairstyle,
            'id_barber' => $request->id_barber,
            'id_service' => $request->id_service,
            'book_date' => $request->book_date,
            'order_date' => $request->order_date,
        ]; 
        if($this->db->where('id',$id)->update($this->table, $updateData)){ 
            return ['msg'=>'Success','error'=>false]; 
        } 
        return ['msg'=>'Failed','error'=>true]; 
    } 
        
    public function destroy($id){ 
        if (empty($this->db->select('*')->where(array('id' => $id))->get($this->table)->row())) 
        return ['msg'=>'Id tidak ditemukan','error'=>true]; 
        if($this->db->delete($this->table, array('id' => $id))){ 
            return ['msg'=>'Success','error'=>false]; 
        } 
        return ['msg'=>'Failed','error'=>true]; 
    } 

    
} 
?>