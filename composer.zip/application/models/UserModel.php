<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
class UserModel extends CI_Model 
{ 
    private $table = 'users'; 
    public $id; 
    public $full_name; 
    public $email; 
    public $password; 
    public $verified;
    public $profile_pict;
    public $rule = [ 
        [ 
            'field' => 'full_name', 
            'label' => 'full_name', 
            'rules' => 'required' 
        ], 
    ]; 
    public function Rules() { return $this->rule; } 
    
    function get_user($q) {
		return $this->db->get_where('users',$q);
	} 
    
    public function store($request) { 
        $this->full_name = $request->full_name; 
        $this->email = $request->email; 
        $this->password = password_hash($request->password, PASSWORD_BCRYPT);
        $this->verified = 0;
        
        
        $this->profile_pict = $this->_uploadImage(); 
        if($this->db->insert($this->table, $this)){ 
            return ['msg'=>'Success','error'=>false];
        } 
        return ['msg'=>'Failed','error'=>true]; 
    } 
    public function update($request,$id) { 
        $updateData = [
            'email' => $request->email, 
            'full_name' =>$request->full_name,
            'password' =>password_hash($request->password, PASSWORD_BCRYPT),
            'profile_pict' =>$request->profile_pict
        ]; 
        if($this->db->where('id',$id)->update($this->table, $updateData)){ 
            return ['msg'=>'Success','error'=>false]; 
        } 
        return ['msg'=>'Failed','error'=>true]; 
    } 
        
    public function destroy($id){ 
        if (empty($this->db->select('*')->where(array('id' => $id))->get($this->table)->row())) 
        return ['msg'=>'Id tidak ditemukan','error'=>true]; 
        if($this->db->delete($this->table, array('id' => $id))){ 
            return ['msg'=>'Success','error'=>false]; 
        } 
        return ['msg'=>'Failed','error'=>true]; 
    } 

    private function _uploadImage()
    {
        $config['upload_path']          = '../FrontendTubes/src/assets/upload/profile_pict/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['file_name']            = $this->full_name;
        $config['overwrite']			= true;
        $config['max_size']             = 1024; // 1MB
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('profile_pict')) {
            return $this->upload->data("file_name");
        }else{
            return "default.jpg";
        }
        
        
    }
} 
?>