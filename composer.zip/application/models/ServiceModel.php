<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
class ServiceModel extends CI_Model 
{ 
    private $table = 'services'; 
    public $id; 
    public $name; 
    public $description; 
    public $price; 
    public $rule = [ 
        [ 
            'field' => 'name', 
            'label' => 'name', 
            'rules' => 'required' 
        ], 
        // [ 
        //     'field' => 'email', 
        //     'label' => 'email', 
        //     'rules' => 'required' 
        // ],
        // [ 
        //     'field' => 'phone', 
        //     'label' => 'phone', 
        //     'rules' => 'required' 
        // ],
    ]; 
    public function Rules() { return $this->rule; } 
    
    // public function getAll() { return 
    //     $this->db->get('data_mahasiswa')->result(); 
    // } 
    
    public function store($request) { 
        $this->name = $request->name; 
        $this->description = $request->description; 
        $this->price = $request->price; 
        if($this->db->insert($this->table, $this)){ 
            return ['msg'=>'Success','error'=>false];
        } 
        return ['msg'=>'Failed','error'=>true]; 
    } 
    public function update($request,$id) { 
        $updateData = [
            'name' => $request->name,
            'description' => $request->description,
            'price' => $request->price,
        ]; 
        if($this->db->where('id',$id)->update($this->table, $updateData)){ 
            return ['msg'=>'Success','error'=>false]; 
        } 
        return ['msg'=>'Failed','error'=>true]; 
    } 
        
    public function destroy($id){ 
        if (empty($this->db->select('*')->where(array('id' => $id))->get($this->table)->row())) 
        return ['msg'=>'Id tidak ditemukan','error'=>true]; 
        if($this->db->delete($this->table, array('id' => $id))){ 
            return ['msg'=>'Success','error'=>false]; 
        } 
        return ['msg'=>'Failed','error'=>true]; 
    } 
} 
?>