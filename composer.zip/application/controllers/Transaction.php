<?php 
use Restserver \Libraries\REST_Controller ; 
Class Transaction extends REST_Controller{

    public function __construct(){ 
        header('Access-Control-Allow-Origin: www.barbarbershop.online'); 
        header("Access-Control-Allow-Methods: GET, OPTIONS, POST, DELETE"); 
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding"); 
        parent::__construct(); $this->load->model('TransactionModel'); $this->load->library('form_validation'); 
    } 
    public function index_get(){ 
        $this->db->select('u.full_name as user_name, b.name as barber_name, h.name as hair_name, s.name as service_name,s.price as total, t.book_date as book_date, t.order_date as order_date');
        $this->db->from('transactions as t');
        $this->db->join('users as u', 'u.id = t.id_user');
        $this->db->join('barbers as b', 'b.id = t.id_barber');
        $this->db->join('hairstyles as h', 'h.id = t.id_hairstyle');
        $this->db->join('services as s', 's.id = t.id_service');
        $query=$this->db->get();
        $data=$query->result_array();
        return $this->returnData($data, false); 
    }

    // public function index_getByID($id = null){ 
    //     if($id == null){ 
    //         return $this->returnData('Parameter Id Tidak Ditemukan', true); 
    //     }
    //     $this->db->select('u.full_name as user_name, b.name as barber_name, h.name as hair_name, s.name as service_name, t.book_date as book_date, t.order_date as order_date');
    //     $this->db->from('transactions as t');
    //     $this->db->join('users as u', 'u.id = t.id_user');
    //     $this->db->join('barbers as b', 'b.id = t.id_barber');
    //     $this->db->join('hairstyles as h', 'h.id = t.id_hairstyle');
    //     $this->db->join('services as s', 's.id = t.id_service');
    //     $this->db->where('u.id', $id);
    //     $query=$this->db->get();
    //     $data=$query->result_array();
    //     return $this->returnData($this->db->get('transactions')->result(), false); 
    // } 

    public function index_post($id = null){ 
        $validation = $this->form_validation; 
        $rule = $this->TransactionModel->rules(); 
        if($id == null){ 
            array_push($rule,
            [ 
                'field' => 'id_user', 
                'label' => 'id_user', 
                'rules' => 'required' 
            ], 
            [ 
                'field' => 'id_hairstyle', 
                'label' => 'id_hairstyle', 
                'rules' => 'required' 
            ],
            [ 
                'field' => 'id_barber', 
                'label' => 'id_barber', 
                'rules' => 'required' 
            ],
            [ 
                'field' => 'id_service', 
                'label' => 'id_service', 
                'rules' => 'required' 
            ], 
        ); 
        } else{ 
            array_push($rule, 
                [ 
                    'field' => 'id_user', 
                    'label' => 'id_user', 
                    'rules' => 'required' 
                ], 
                [ 
                    'field' => 'id_hairstyle', 
                    'label' => 'id_hairstyle', 
                    'rules' => 'required' 
                ],
                [ 
                    'field' => 'id_barber', 
                    'label' => 'id_barber', 
                    'rules' => 'required' 
                ],
                [ 
                    'field' => 'id_service', 
                    'label' => 'id_service', 
                    'rules' => 'required' 
                ],
            ); 
        } 
        $validation->set_rules($rule); 
        if (!$validation->run()) { 
            return $this->returnData($this->form_validation->error_array(), true); 
        } 
        $transaction = new TransactionData(); 
        $transaction->id_user = $this->post('id_user');
        $transaction->id_hairstyle = $this->post('id_hairstyle');
        $transaction->id_barber = $this->post('id_barber');
        $transaction->id_service = $this->post('id_service');
        $transaction->book_date = $this->post('book_date');
        $transaction->order_date = $this->post('order_date');
        if($id == null){ 
            $response = $this->TransactionModel->store($transaction);
        }else{ 
            $response = $this->TransactionModel->update($transaction,$id); 
        } 
        return $this->returnData($response['msg'], $response['error']); 
    } 
    public function index_delete($id = null){ 
        if($id == null){ 
            return $this->returnData('Parameter Id Tidak Ditemukan', true); 
        } 
        $response = $this->TransactionModel->destroy($id); 
        return $this->returnData($response['msg'], $response['error']); 
    } 
    public function returnData($msg,$error){ 
        $response['error']=$error; 
        $response['message']=$msg; 
        return $this->response($response); 
    } 
} 
Class TransactionData{ 
    public $id_user; 
    public $id_hairstyle; 
    public $id_barber; 
    public $id_service;
    public $book_date;
    public $order_date;
}